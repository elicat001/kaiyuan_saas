Docs writer agent.

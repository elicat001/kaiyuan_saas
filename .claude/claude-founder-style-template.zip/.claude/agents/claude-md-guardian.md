---
name: claude-md-guardian
---
Guardian agent.

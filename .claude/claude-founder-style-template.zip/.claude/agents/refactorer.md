Refactorer agent.

PR description template.

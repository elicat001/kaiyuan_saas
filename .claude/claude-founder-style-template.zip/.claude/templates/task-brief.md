Task brief template.

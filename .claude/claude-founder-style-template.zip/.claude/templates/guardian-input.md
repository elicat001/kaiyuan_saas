Guardian input template.

update-claude-md command.

e2e-verify command.

commit-push-pr command.

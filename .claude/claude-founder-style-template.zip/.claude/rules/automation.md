Automation rules.

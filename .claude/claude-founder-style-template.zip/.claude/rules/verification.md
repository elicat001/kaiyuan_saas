Verification rules.

Project style rules.
